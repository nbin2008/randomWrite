export const increment = ({dispatch}) => dispatch('INCREMENT');
export const decrement = ({dispatch}) => dispatch('DECREMENT');